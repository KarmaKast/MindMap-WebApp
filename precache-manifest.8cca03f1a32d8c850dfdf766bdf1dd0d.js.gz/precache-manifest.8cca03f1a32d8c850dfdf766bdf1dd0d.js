self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7b98a5a1c7c6c8e79e25",
    "url": "/MindMap-WebApp/css/app.f87d7806.css"
  },
  {
    "revision": "2962b501bf45a549bb73",
    "url": "/MindMap-WebApp/css/chunk-entity-component.ba14ae91.css"
  },
  {
    "revision": "1064b931d6730445898c",
    "url": "/MindMap-WebApp/css/chunk-icon-base.a3bf5cbe.css"
  },
  {
    "revision": "bae9ca5f264178972bc5",
    "url": "/MindMap-WebApp/css/chunk-mindmap-module.cc95ed14.css"
  },
  {
    "revision": "fccc80df3856685e0082",
    "url": "/MindMap-WebApp/css/chunk-relation-label.dec5667e.css"
  },
  {
    "revision": "5e761701e677d428a009e97ace63b863",
    "url": "/MindMap-WebApp/index.html"
  },
  {
    "revision": "7b98a5a1c7c6c8e79e25",
    "url": "/MindMap-WebApp/js/app-legacy.a89c8564.js"
  },
  {
    "revision": "1b588c5186e8310e463c",
    "url": "/MindMap-WebApp/js/chunk-2d0c115c-legacy.22fda05e.js"
  },
  {
    "revision": "cd9a4eac837f0f2902c5",
    "url": "/MindMap-WebApp/js/chunk-2d2079a5-legacy.e650aad9.js"
  },
  {
    "revision": "c5cb520b12cbe7867dc6",
    "url": "/MindMap-WebApp/js/chunk-about-page-legacy.e3ac875a.js"
  },
  {
    "revision": "24ce556edcf2d5dc3edd",
    "url": "/MindMap-WebApp/js/chunk-button1-legacy.3e648f4e.js"
  },
  {
    "revision": "bbe5777e159b9948fcd5",
    "url": "/MindMap-WebApp/js/chunk-button2-legacy.2e44024e.js"
  },
  {
    "revision": "2962b501bf45a549bb73",
    "url": "/MindMap-WebApp/js/chunk-entity-component-legacy.21b916d1.js"
  },
  {
    "revision": "31c1dd3b48b951c77931",
    "url": "/MindMap-WebApp/js/chunk-icon-Hamburger1-legacy.e949df4b.js"
  },
  {
    "revision": "1064b931d6730445898c",
    "url": "/MindMap-WebApp/js/chunk-icon-base-legacy.7984d629.js"
  },
  {
    "revision": "9339eb95d5dae19aebbb",
    "url": "/MindMap-WebApp/js/chunk-mindmap-canvas-legacy.50c66770.js"
  },
  {
    "revision": "bae9ca5f264178972bc5",
    "url": "/MindMap-WebApp/js/chunk-mindmap-module-legacy.2d69efa2.js"
  },
  {
    "revision": "fccc80df3856685e0082",
    "url": "/MindMap-WebApp/js/chunk-relation-label-legacy.c0e2d49b.js"
  },
  {
    "revision": "f6272a4a077e7df6532a",
    "url": "/MindMap-WebApp/js/chunk-vendors-legacy.76e445c6.js"
  },
  {
    "revision": "fac6748b1a643c19a017",
    "url": "/MindMap-WebApp/js/chunk-vue-konva-legacy.aedc352a.js"
  },
  {
    "revision": "d87f02aefc5fcddf141eaeb45bec2375",
    "url": "/MindMap-WebApp/manifest.json"
  }
]);