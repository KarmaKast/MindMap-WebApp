self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0228f04ca5371779d71f",
    "url": "/MindMap-WebApp/css/app.f87d7806.css"
  },
  {
    "revision": "0a57b84bffa2dde5a91d",
    "url": "/MindMap-WebApp/css/chunk-entity-component.b5c70a2c.css"
  },
  {
    "revision": "5063a50027797728114c",
    "url": "/MindMap-WebApp/css/chunk-icon-base.a3bf5cbe.css"
  },
  {
    "revision": "e892315b57fbd537a610",
    "url": "/MindMap-WebApp/css/chunk-mindmap-module.d8b6719b.css"
  },
  {
    "revision": "bf2a40ca4cbde913c6a2",
    "url": "/MindMap-WebApp/css/chunk-relation-label.dec5667e.css"
  },
  {
    "revision": "d71080b4c3c0cfa477d38397b5842a61",
    "url": "/MindMap-WebApp/index.html"
  },
  {
    "revision": "0228f04ca5371779d71f",
    "url": "/MindMap-WebApp/js/app.5f27c9d3.js"
  },
  {
    "revision": "9dc0b26fda313d6b79d2",
    "url": "/MindMap-WebApp/js/chunk-2d0c115c.9ea5727a.js"
  },
  {
    "revision": "2881c254a842477e52c5",
    "url": "/MindMap-WebApp/js/chunk-2d2079a5.d69c7de7.js"
  },
  {
    "revision": "453f7424de773f8e5254",
    "url": "/MindMap-WebApp/js/chunk-about-page.a464cf47.js"
  },
  {
    "revision": "96647777e73985e590d4",
    "url": "/MindMap-WebApp/js/chunk-button1.6f286d92.js"
  },
  {
    "revision": "6b1328cf6c4250537e67",
    "url": "/MindMap-WebApp/js/chunk-button2.30b4aa2e.js"
  },
  {
    "revision": "0a57b84bffa2dde5a91d",
    "url": "/MindMap-WebApp/js/chunk-entity-component.77232c36.js"
  },
  {
    "revision": "ece9ff669f144bd20947",
    "url": "/MindMap-WebApp/js/chunk-icon-Hamburger1.2787e402.js"
  },
  {
    "revision": "5063a50027797728114c",
    "url": "/MindMap-WebApp/js/chunk-icon-base.94550dac.js"
  },
  {
    "revision": "fe28508e480cb10b3b4a",
    "url": "/MindMap-WebApp/js/chunk-mindmap-canvas.9a236382.js"
  },
  {
    "revision": "e892315b57fbd537a610",
    "url": "/MindMap-WebApp/js/chunk-mindmap-module.00885b7f.js"
  },
  {
    "revision": "bf2a40ca4cbde913c6a2",
    "url": "/MindMap-WebApp/js/chunk-relation-label.9642e864.js"
  },
  {
    "revision": "059dc7ae1bfcef5613b5",
    "url": "/MindMap-WebApp/js/chunk-vendors.911cf1df.js"
  },
  {
    "revision": "fac6748b1a643c19a017",
    "url": "/MindMap-WebApp/js/chunk-vue-konva.aedc352a.js"
  },
  {
    "revision": "d87f02aefc5fcddf141eaeb45bec2375",
    "url": "/MindMap-WebApp/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/MindMap-WebApp/robots.txt"
  }
]);