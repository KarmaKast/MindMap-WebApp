self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "52b8fe5f745e1109ba7b",
    "url": "/MindMap-WebApp/css/app.f87d7806.css"
  },
  {
    "revision": "2e43cb2202ff7a94a029",
    "url": "/MindMap-WebApp/css/chunk-entity-component.e048511e.css"
  },
  {
    "revision": "d9938460ff7e775aa2a2",
    "url": "/MindMap-WebApp/css/chunk-icon-base.a3bf5cbe.css"
  },
  {
    "revision": "29090b889ca9cc30bd28",
    "url": "/MindMap-WebApp/css/chunk-mindmap-module.3804cad3.css"
  },
  {
    "revision": "1dcb675ed4e1159c38d5",
    "url": "/MindMap-WebApp/css/chunk-relation-label.6e02a65c.css"
  },
  {
    "revision": "46fdd083e763e56a78a0f77a7c83f4f4",
    "url": "/MindMap-WebApp/index.html"
  },
  {
    "revision": "52b8fe5f745e1109ba7b",
    "url": "/MindMap-WebApp/js/app-legacy.79970c74.js"
  },
  {
    "revision": "df189b6d2a032d5317e1",
    "url": "/MindMap-WebApp/js/chunk-2d0c115c-legacy.d50c0e6c.js"
  },
  {
    "revision": "4576a26174ef8ae644ad",
    "url": "/MindMap-WebApp/js/chunk-2d2079a5-legacy.80704292.js"
  },
  {
    "revision": "dc2570132926dc81e7b4",
    "url": "/MindMap-WebApp/js/chunk-about-page-legacy.f723cc11.js"
  },
  {
    "revision": "4732b01e85b043e675fb",
    "url": "/MindMap-WebApp/js/chunk-button1-legacy.3ce490b1.js"
  },
  {
    "revision": "e90d266d0090be1c706e",
    "url": "/MindMap-WebApp/js/chunk-button2-legacy.e27f836a.js"
  },
  {
    "revision": "2e43cb2202ff7a94a029",
    "url": "/MindMap-WebApp/js/chunk-entity-component-legacy.1c18d023.js"
  },
  {
    "revision": "197b5cbb004f3520f780",
    "url": "/MindMap-WebApp/js/chunk-icon-Hamburger1-legacy.529c7401.js"
  },
  {
    "revision": "d9938460ff7e775aa2a2",
    "url": "/MindMap-WebApp/js/chunk-icon-base-legacy.df603466.js"
  },
  {
    "revision": "6da2237d5dd29b7ed184",
    "url": "/MindMap-WebApp/js/chunk-mindmap-canvas-legacy.0fbf4d43.js"
  },
  {
    "revision": "29090b889ca9cc30bd28",
    "url": "/MindMap-WebApp/js/chunk-mindmap-module-legacy.3d6c0330.js"
  },
  {
    "revision": "1dcb675ed4e1159c38d5",
    "url": "/MindMap-WebApp/js/chunk-relation-label-legacy.6a31811d.js"
  },
  {
    "revision": "f6272a4a077e7df6532a",
    "url": "/MindMap-WebApp/js/chunk-vendors-legacy.76e445c6.js"
  },
  {
    "revision": "fac6748b1a643c19a017",
    "url": "/MindMap-WebApp/js/chunk-vue-konva-legacy.aedc352a.js"
  },
  {
    "revision": "d87f02aefc5fcddf141eaeb45bec2375",
    "url": "/MindMap-WebApp/manifest.json"
  }
]);