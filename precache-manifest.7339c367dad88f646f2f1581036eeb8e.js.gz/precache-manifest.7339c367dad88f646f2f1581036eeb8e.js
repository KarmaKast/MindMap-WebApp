self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f7dca60828dba26acf0b",
    "url": "/MindMap-WebApp/css/app.f87d7806.css"
  },
  {
    "revision": "d91fd1e20c9dd56e4c33",
    "url": "/MindMap-WebApp/css/chunk-entity-component.b5c70a2c.css"
  },
  {
    "revision": "6b4f4f9868e23173ccef",
    "url": "/MindMap-WebApp/css/chunk-icon-base.a3bf5cbe.css"
  },
  {
    "revision": "4b15305cdbdaa6dc860b",
    "url": "/MindMap-WebApp/css/chunk-mindmap-module.d8b6719b.css"
  },
  {
    "revision": "bb67776e823f9164a846",
    "url": "/MindMap-WebApp/css/chunk-relation-label.dec5667e.css"
  },
  {
    "revision": "8c10021ac4708d65f8a23fa8a031bd33",
    "url": "/MindMap-WebApp/index.html"
  },
  {
    "revision": "f7dca60828dba26acf0b",
    "url": "/MindMap-WebApp/js/app-legacy.6e88aabd.js"
  },
  {
    "revision": "9dc0b26fda313d6b79d2",
    "url": "/MindMap-WebApp/js/chunk-2d0c115c-legacy.9ea5727a.js"
  },
  {
    "revision": "2881c254a842477e52c5",
    "url": "/MindMap-WebApp/js/chunk-2d2079a5-legacy.d69c7de7.js"
  },
  {
    "revision": "0b6a404b2780dc98b90e",
    "url": "/MindMap-WebApp/js/chunk-about-page-legacy.9b17a806.js"
  },
  {
    "revision": "6d94a678f22e63465532",
    "url": "/MindMap-WebApp/js/chunk-button1-legacy.db85d1d2.js"
  },
  {
    "revision": "81f708f0076f4ee2a8cf",
    "url": "/MindMap-WebApp/js/chunk-button2-legacy.a17dece6.js"
  },
  {
    "revision": "d91fd1e20c9dd56e4c33",
    "url": "/MindMap-WebApp/js/chunk-entity-component-legacy.c907ec8b.js"
  },
  {
    "revision": "ece9ff669f144bd20947",
    "url": "/MindMap-WebApp/js/chunk-icon-Hamburger1-legacy.2787e402.js"
  },
  {
    "revision": "6b4f4f9868e23173ccef",
    "url": "/MindMap-WebApp/js/chunk-icon-base-legacy.2902e00a.js"
  },
  {
    "revision": "3e7d46db0ea50bd69ef2",
    "url": "/MindMap-WebApp/js/chunk-mindmap-canvas-legacy.ab2ae6ec.js"
  },
  {
    "revision": "4b15305cdbdaa6dc860b",
    "url": "/MindMap-WebApp/js/chunk-mindmap-module-legacy.e18f3048.js"
  },
  {
    "revision": "bb67776e823f9164a846",
    "url": "/MindMap-WebApp/js/chunk-relation-label-legacy.60f88d4e.js"
  },
  {
    "revision": "f6272a4a077e7df6532a",
    "url": "/MindMap-WebApp/js/chunk-vendors-legacy.76e445c6.js"
  },
  {
    "revision": "fac6748b1a643c19a017",
    "url": "/MindMap-WebApp/js/chunk-vue-konva-legacy.aedc352a.js"
  },
  {
    "revision": "d87f02aefc5fcddf141eaeb45bec2375",
    "url": "/MindMap-WebApp/manifest.json"
  }
]);