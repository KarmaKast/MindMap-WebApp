self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "adc97d0d31acf5b96f5d",
    "url": "/MindMap-WebApp/css/app.f87d7806.css"
  },
  {
    "revision": "d48c9551aa5ed89d65d1",
    "url": "/MindMap-WebApp/css/chunk-entity-component.e048511e.css"
  },
  {
    "revision": "ccd43525e7c138b24366",
    "url": "/MindMap-WebApp/css/chunk-icon-base.a3bf5cbe.css"
  },
  {
    "revision": "73dadd5a0f86f1265b78",
    "url": "/MindMap-WebApp/css/chunk-mindmap-module.3804cad3.css"
  },
  {
    "revision": "713a6c09989623a5ebe1",
    "url": "/MindMap-WebApp/css/chunk-relation-label.6e02a65c.css"
  },
  {
    "revision": "dd093bff9aa5fea5f1d455034ea84693",
    "url": "/MindMap-WebApp/index.html"
  },
  {
    "revision": "adc97d0d31acf5b96f5d",
    "url": "/MindMap-WebApp/js/app.142d0314.js"
  },
  {
    "revision": "df189b6d2a032d5317e1",
    "url": "/MindMap-WebApp/js/chunk-2d0c115c.d50c0e6c.js"
  },
  {
    "revision": "4576a26174ef8ae644ad",
    "url": "/MindMap-WebApp/js/chunk-2d2079a5.80704292.js"
  },
  {
    "revision": "ade88c53002e8be8ce9d",
    "url": "/MindMap-WebApp/js/chunk-about-page.450316ec.js"
  },
  {
    "revision": "028c6681b60f0a8719b9",
    "url": "/MindMap-WebApp/js/chunk-button1.6b344bbc.js"
  },
  {
    "revision": "086126a8b5227df0be91",
    "url": "/MindMap-WebApp/js/chunk-button2.7cc0583a.js"
  },
  {
    "revision": "d48c9551aa5ed89d65d1",
    "url": "/MindMap-WebApp/js/chunk-entity-component.765f48a0.js"
  },
  {
    "revision": "197b5cbb004f3520f780",
    "url": "/MindMap-WebApp/js/chunk-icon-Hamburger1.529c7401.js"
  },
  {
    "revision": "ccd43525e7c138b24366",
    "url": "/MindMap-WebApp/js/chunk-icon-base.f7779c6e.js"
  },
  {
    "revision": "4534a1eea84241989992",
    "url": "/MindMap-WebApp/js/chunk-mindmap-canvas.7ee9275a.js"
  },
  {
    "revision": "73dadd5a0f86f1265b78",
    "url": "/MindMap-WebApp/js/chunk-mindmap-module.63ee7289.js"
  },
  {
    "revision": "713a6c09989623a5ebe1",
    "url": "/MindMap-WebApp/js/chunk-relation-label.115a146d.js"
  },
  {
    "revision": "059dc7ae1bfcef5613b5",
    "url": "/MindMap-WebApp/js/chunk-vendors.911cf1df.js"
  },
  {
    "revision": "fac6748b1a643c19a017",
    "url": "/MindMap-WebApp/js/chunk-vue-konva.aedc352a.js"
  },
  {
    "revision": "d87f02aefc5fcddf141eaeb45bec2375",
    "url": "/MindMap-WebApp/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/MindMap-WebApp/robots.txt"
  }
]);